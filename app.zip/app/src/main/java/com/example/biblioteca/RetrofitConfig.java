package com.example.biblioteca;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitConfig {

 private final Retrofit retrofit;

    public RetrofitConfig() {
        this.retrofit = new retrofit2.Retrofit.Builder().baseUrl("http://demo5199886.mockable.io/").addConverterFactory(GsonConverterFactory.create()).build();
    }

    public LivrosService getLivroService(){ return this.retrofit.create(LivrosService.class); }

}
