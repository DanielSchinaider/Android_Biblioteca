package com.example.biblioteca;

import android.view.View;

public interface ClickEvent {

    void click(View view, int pos);

}
