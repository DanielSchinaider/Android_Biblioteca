package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.biblioteca.databinding.ActivityListagemLivrosBinding;
import com.example.biblioteca.databinding.ActivityMainBinding;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListagemLivros extends AppCompatActivity {

    private ActivityListagemLivrosBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_listagem_livros);
        ButterKnife.bind(this);

        RetrofitConfig config = new RetrofitConfig();

        config.getLivroService().getLivros().enqueue(new Callback<List<LivrosIO>>() {
            @Override
            public void onResponse(Call<List<LivrosIO>> call, Response<List<LivrosIO>> response) {
                if(!response.isSuccessful()){
                    Toast.makeText(ListagemLivros.this, "Sem resultados", Toast.LENGTH_LONG).show();
                    return;
                }

                List<LivrosIO> lista;
                lista = response.body();

                RecyclerView  recyclerView = findViewById(R.id.recycleLista);
                Adapter adapter = new Adapter(lista, ListagemLivros.this, new Adapter.ItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {

                            String valores[] = new String[]{

                                    lista.get(position).getImagem(),
                                    lista.get(position).getNome(),
                                    lista.get(position).getAutor(),
                                    lista.get(position).getAno(),
                                    lista.get(position).getResumo()

                            };

                            Picasso.get().load(valores[0]).into(binding.imagemLivro);
                            binding.txtCabecalhoNome.setText(valores[1]);
                            binding.txtCabecalhoAutor.setText(valores[2]);
                            binding.txtCabecalhoAno.setText(valores[3]);

                        }


                });
                adapter.setClickEvent((View view, int pos) -> {
                    Toast.makeText(ListagemLivros.this, Integer.toString(pos), Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(getBaseContext(), ResenhaLivro.class);
                    intent.putExtra("imagem", lista.get(pos).getImagem());
                    intent.putExtra("nome", lista.get(pos).getNome());
                    intent.putExtra("autor", lista.get(pos).getAutor());
                    intent.putExtra("ano", lista.get(pos).getAno());
                    intent.putExtra("resumo", lista.get(pos).getResumo());

                    startActivity(intent);

                });
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(ListagemLivros.this, RecyclerView.VERTICAL, false));
            }

            @Override
            public void onFailure(Call<List<LivrosIO>> call, Throwable t) {
                Toast.makeText(ListagemLivros.this, "Falha!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void chamarResumo(View view){
        Intent intent = new Intent(this, ResenhaLivro.class);
        startActivity(intent);
    }

}