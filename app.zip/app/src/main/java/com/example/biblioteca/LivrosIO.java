package com.example.biblioteca;

public class LivrosIO {

    private String nome;
    private String autor;
    private String ano;
    private String imagem;
    private String resumo;

    public LivrosIO(String nome, String autor, String ano, String imagem, String resumo) {
        this.nome = nome;
        this.autor = autor;
        this.ano = ano;
        this.imagem = imagem;
        this.resumo = resumo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getResumo() {
        return resumo;
    }

    public void setResumo(String resumo) {
        this.resumo = resumo;
    }
}
