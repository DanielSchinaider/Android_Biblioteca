package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;

import com.example.biblioteca.databinding.ActivityListagemLivrosBinding;
import com.example.biblioteca.databinding.ActivityResenhaLivroBinding;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResenhaLivro extends AppCompatActivity {

    private ActivityResenhaLivroBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_resenha_livro);
        ButterKnife.bind(this);

        String nome = getIntent().getStringExtra("nome");
        String ano = getIntent().getStringExtra("ano");
        String autor = getIntent().getStringExtra("autor");
        String resumo = getIntent().getStringExtra("resumo");
        String imagem = getIntent().getStringExtra("imagem");

        binding.txtResenhaNome.setText(nome);
        binding.txtResenhaAno.setText(ano);
        binding.txtResenhaAutor.setText(autor);
        binding.txtResenhaResumo.setText(resumo);
        Picasso.get().load(imagem).resize(300,300).into(binding.imgResenha);

    }
}