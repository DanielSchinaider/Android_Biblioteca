package com.example.biblioteca;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.io.Console;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<LivrosIO> mData;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;
    private Context context;
    private ClickEvent clickEvent;


    public Adapter(List<LivrosIO> mData, Context context, ItemClickListener clickListener) {
        this.mData = mData;
        this.mInflater = LayoutInflater.from(context);
        this.mClickListener = clickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerow, parent, false);
        return new ViewHolder(view);
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        String nome = mData.get(position).getNome();
        String txtImg = mData.get(position).getImagem();

        holder.txtNome.setText(nome);

        Picasso.get().load(txtImg).resize(200,200).into(holder.imgLivro);
        holder.resumo.setOnClickListener((View view) -> {
            if(this.clickEvent == null){
                return;
            }
            this.clickEvent.click(view, position);
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView txtNome, txtCabecalhoAutor, txtCabecalhoAno, txtCabecalhoNome;
        ImageView imgLivro, imagemLivro;
        Button resumo;

        ViewHolder(View itemView){
            super(itemView);
            txtNome = itemView.findViewById(R.id.txtNome);
            imgLivro = itemView.findViewById(R.id.imgLivro);
            resumo = itemView.findViewById(R.id.btnResumo);

            txtCabecalhoNome = itemView.findViewById(R.id.txtCabecalhoNome);
            txtCabecalhoAno = itemView.findViewById(R.id.txtResenhaAno);
            txtCabecalhoAutor = itemView.findViewById(R.id.txtCabecalhoAutor);
            imagemLivro = itemView.findViewById(R.id.imagemLivro);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null){
                mClickListener.onItemClick(view, getAdapterPosition());

            }
        }

    }

    public void setClickEvent(ClickEvent clickEvent) {
        this.clickEvent = clickEvent;
    }

    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}
